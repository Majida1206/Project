import numpy as np
import pandas as pd
df_new_2=pd.read_csv(r"C:\Users\Smile\Downloads\Phishingnewdataset2.csv")

# Split data
X1=df_new_2.drop(['label'],axis=1)
Y1=df_new_2['label']


from sklearn.model_selection import train_test_split
X1_train,X1_test,Y1_train,Y1_test=train_test_split(X1,Y1,test_size=0.2,random_state=42)

from sklearn.ensemble import RandomForestClassifier
rf_model=RandomForestClassifier(n_estimators=100,random_state=42)
rf_model.fit(X1_train,Y1_train)
Y_pred2=rf_model.predict(X1_test)
import pickle
# Save train model
pickle.dump(rf_model, open('phishing_model.pickle', 'wb'))






